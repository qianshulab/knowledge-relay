<div align="center">

# 知流同步

### 将微信中的碎片内容，稳定写入你的 Obsidian 收件箱

[![CI](https://github.com/qianshulab/knowledge-relay-obsidian/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/qianshulab/knowledge-relay-obsidian/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/qianshulab/knowledge-relay-obsidian?display_name=tag&sort=semver)](https://github.com/qianshulab/knowledge-relay-obsidian/releases/latest)
[![Obsidian](https://img.shields.io/badge/Obsidian-1.5.0%2B-7C3AED?logo=obsidian&logoColor=white)](https://obsidian.md/)
[![License](https://img.shields.io/github/license/qianshulab/knowledge-relay-obsidian)](./LICENSE)

[下载插件](https://github.com/qianshulab/knowledge-relay-obsidian/releases/latest) · [知流服务端](https://github.com/qianshulab/knowledge-relay) · [问题反馈](https://github.com/qianshulab/knowledge-relay-obsidian/issues)

</div>

---

知流同步是 [Knowledge Relay](https://github.com/qianshulab/knowledge-relay) 的 Obsidian 客户端。它将知流收件台中的微信消息、整理结果、原始附件和网页 Markdown 增量写入指定目录，并在同步成功后向服务端确认归档。

插件只负责可靠同步与本地笔记维护。内容接收、网页解析和智能整理均由知流服务端与 Nanobot Runtime 完成。

## 主要能力

| 能力 | 说明 |
|---|---|
| 增量同步 | 只拉取上次成功同步之后的新内容，支持分页处理大批量收件 |
| 稳定去重 | 以服务端永久 ID 识别内容，不依赖标题、文件名或模型结果 |
| 原位更新 | 同一条内容完成智能整理后更新原笔记，不创建重复副本 |
| 模板写入 | 支持自定义收件模板，同时保留用户维护的正文区域 |
| 附件校验 | 下载图片、文件和派生 Markdown，并校验 SHA-256 完整性 |
| 断点恢复 | 仅在整批笔记与附件写入成功后确认；中断后自动重试 |
| 冲突保护 | 无法安全更新旧笔记时报告冲突，不覆盖整篇内容 |
| 状态可见 | 状态栏、命令面板与通知共同呈现同步进度和错误信息 |

## 工作方式

```mermaid
flowchart LR
    K["知流收件台"] -->|"增量批次"| P["知流同步插件"]
    P --> V["Obsidian 收件箱"]
    P --> A["附件目录"]
    P -->|"全部写入成功后确认"| K
```

服务端会先发布原始消息，再在智能整理完成后发布同一远程 ID 的新修订。插件根据稳定 ID 找到已有笔记，只更新知流托管的内容和同步元数据。

## 安装

### 从知流管理后台安装

1. 打开知流的“Obsidian 同步”页面，下载插件 ZIP。
2. 解压后，将 `wechat-ilink-inbox-sync` 目录放入 Vault 的 `.obsidian/plugins/`。
3. 重启 Obsidian，在“设置 → 第三方插件”中启用“知流同步”。

### 从 GitHub Releases 安装

1. 从 [Releases](https://github.com/qianshulab/knowledge-relay-obsidian/releases/latest) 下载最新 ZIP。
2. 解压到 `<Vault>/.obsidian/plugins/wechat-ilink-inbox-sync/`。
3. 确认目录中包含 `main.js`、`manifest.json` 和 `styles.css`，然后启用插件。

> 插件要求 Obsidian 1.5.0 或更高版本，支持桌面端和移动端。

## 连接知流

1. 在知流“Obsidian 同步”页面创建连接。
2. 复制只显示一次的 `obsidian_...` 连接令牌。
3. 打开 Obsidian“设置 → 知流同步”。
4. 填写服务地址、连接令牌和收件箱目录。
5. 点击“立即同步”完成连接验证。

本机服务可以使用 `http://127.0.0.1:8787`。连接其他主机时必须使用 HTTPS，避免同步令牌通过明文网络传输。

## 同步规则

- Obsidian 启动并完成工作区加载后，默认执行一次同步。
- 周期同步默认关闭；启用后的最短间隔为 5 分钟。
- 每个批次只有在笔记和附件全部写入成功后才会确认。
- 断网、超时或 Obsidian 退出不会丢失进度，下次会重新拉取未确认批次。
- 移出收件箱的笔记视为已处理，后续修订不会将其搬回。
- 删除本地笔记会将该远程 ID 标记为已忽略，服务端重放不会重新创建。
- `restricted` 内容不会写入普通 Vault；其他敏感级别可在设置中限制。

## 模板与托管区块

默认模板路径：

```text
90-系统/模板/T-知流收件.md
```

首次启用时，插件会自动创建专用模板；已经设置的自定义模板路径不会被覆盖。支持以下变量：

| 变量 | 内容 |
|---|---|
| `{{title}}` | 笔记标题 |
| `{{date}}` | 收件日期 |
| `{{time}}` | 收件时间 |
| `{{datetime}}` | 完整收件时间 |
| `{{source}}` | 内容来源 |
| `{{message_id}}` | 知流永久消息 ID |
| `{{revision}}` | 当前内容修订号 |

知流维护的内容位于以下标记之间：

```markdown
<!-- knowledge-relay:managed:start -->
这里由知流维护
<!-- knowledge-relay:managed:end -->
```

后续修订只替换托管区块和必要的同步元数据。你添加的状态、自定义标签、任务、下一步和正文备注不会被覆盖。旧笔记没有托管标记时，插件会记录冲突并停止更新该文件。

## 命令面板

| 命令 | 用途 |
|---|---|
| 知流同步：立即同步 | 立即拉取并写入待同步内容 |
| 知流同步：查看上次同步状态 | 查看创建、更新、跳过和冲突数量 |
| 知流同步：重新扫描本地同步记录 | 从 Vault 重建远程 ID 与笔记路径索引 |
| 知流同步：重置同步游标 | 请求服务端完整重放；操作前需要二次确认 |
| 知流同步：打开收件箱 | 打开当前配置的收件目录 |
| 知流同步：查看最近一次错误 | 显示最近同步失败的原因 |

## 常见问题

### 同步成功后没有看到新笔记

检查插件设置中的收件箱目录，并通过命令面板打开“查看上次同步状态”。如果内容已被移动或删除，运行“重新扫描本地同步记录”恢复索引。

### 出现冲突但原笔记没有变化

这是预期的保护行为。插件只会自动更新包含知流托管标记的笔记，不会覆盖无法确认边界的旧文件。保留你的修改后运行“重新扫描本地同步记录”，再重新同步。

### 附件下载失败

插件会校验文件长度和 SHA-256。网络中断或校验失败时不会确认当前批次，修复连接后再次执行同步即可。

### 什么时候需要重置同步游标

只有在需要服务端完整重放时才使用。插件保留本地远程 ID 索引，因此正常情况下不会产生重复笔记。

## 数据与安全

- 同步令牌保存在插件目录的 `data.json` 中，不写入笔记、状态日志或服务端确认内容。
- 非本机 HTTP 地址会被拒绝，远程连接必须使用 HTTPS。
- 外部 Markdown 会移除脚本、危险深链和自动加载的远程图片。
- 单条内容的附件数量、文件大小和总下载体积均设有上限。
- 设备丢失或连接不再使用时，可在知流管理后台立即撤销令牌。

更多信息见 [SECURITY.md](./SECURITY.md)。

## 开发与发布

```bash
npm ci
npm run verify
npm run package
```

源码位于 `src/`，构建使用 esbuild 生成仓库根目录的单文件 `main.js`。发布 ZIP 只包含 Obsidian 运行所需文件，不会在运行时加载额外的本地模块。

提交问题时，请附上 Obsidian 版本、插件版本、运行平台和可脱敏的错误信息。请勿提交服务地址中的私有路径或连接令牌。

## License

[MIT](./LICENSE) © Knowledge Relay
